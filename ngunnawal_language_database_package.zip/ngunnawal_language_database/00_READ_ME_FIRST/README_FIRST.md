Ngunnawal Language Database Working Package

Step completed: source files placed into the right structure and first comparison run completed.

Counts
- Louise XML entries parsed: 1344
- Unique XML headwords: 1343
- Sketch Grammar rows from Claude master table: 758
- Exact or normalised sketch matches in XML: 456
- Probable spelling or variant matches: 50
- Sketch candidates not found in XML: 252
- Priority manual review rows: 440

Folder structure
00_READ_ME_FIRST
01_sources/original
02_extracted/louise_xml_2022
02_extracted/sketch_grammar_claude
03_consolidation
04_review
05_scripts

Important caution
This is a mechanical comparison only. It does not decide whether a word is correct, standard, regional, borrowed, shared, or usable. It only shows where the current source files overlap or diverge.

Next step
Open 04_review/priority_manual_review.csv and check the not_found_in_xml_candidate rows first.
