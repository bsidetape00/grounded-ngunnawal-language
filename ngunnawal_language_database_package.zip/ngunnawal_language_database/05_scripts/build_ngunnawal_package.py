import os, re, csv, json, shutil, zipfile, difflib
from bs4 import BeautifulSoup
from pathlib import Path

BASE = Path('/mnt/data/ngunnawal_language_database')
if BASE.exists(): shutil.rmtree(BASE)
folders = [
 '00_READ_ME_FIRST',
 '01_sources/original',
 '02_extracted/louise_xml_2022',
 '02_extracted/sketch_grammar_claude',
 '03_consolidation',
 '04_review',
 '05_scripts',
]
for f in folders: (BASE/f).mkdir(parents=True, exist_ok=True)

# Copy source files
for src in ['Dictonary 20221004.xml','Dictonary 20221004.xhtml','A Sketch Grammar of Ngl.pdf','From claude.zip']:
    p=Path('/mnt/data')/src
    if p.exists(): shutil.copy2(p, BASE/'01_sources/original'/src)

# Extract Claude outputs
with zipfile.ZipFile('/mnt/data/From claude.zip') as z:
    z.extractall(BASE/'02_extracted/sketch_grammar_claude')

# Parse Louise XML/XHTML structure
xml_path = Path('/mnt/data/Dictonary 20221004.xml')
html = xml_path.read_text(encoding='utf-8', errors='ignore')
soup = BeautifulSoup(html, 'xml')
if not soup.find_all('div'):
    soup = BeautifulSoup(html, 'html.parser')

def clean_text(x):
    if not x: return ''
    return re.sub(r'\s+', ' ', x.get_text(' ', strip=True)).strip()

def direct_entry_children(entry, class_name):
    out=[]
    for sp in entry.find_all(class_=class_name):
        # avoid grabbing text from nested subentries when possible
        parent_entry = sp.find_parent(class_='entry')
        if parent_entry is entry:
            out.append(clean_text(sp))
    return out

entries=[]
for div in soup.find_all('div', class_='entry'):
    eid = div.get('id','')
    hw_tag = div.find(class_='mainheadword')
    headword = clean_text(hw_tag)
    if not headword: continue
    poss = []
    for p in div.find_all(class_='partofspeech'):
        if p.find_parent(class_='entry') is div:
            t = clean_text(p)
            if t and t not in poss: poss.append(t)
    morph_types=[]
    for m in div.find_all(class_='morphtype'):
        if m.find_parent(class_='entry') is div:
            t=clean_text(m)
            if t and t not in morph_types: morph_types.append(t)
    defs=[]
    for d in div.find_all(class_='definitionorgloss'):
        if d.find_parent(class_='entry') is div:
            t=clean_text(d)
            if t and t not in defs: defs.append(t)
    dialects=[]
    for dl in div.find_all(class_='dialectlabelsr'):
        if dl.find_parent(class_='entry') is div:
            t=clean_text(dl)
            if t and t not in dialects: dialects.append(t)
    sci=[]
    for s in div.find_all(class_='scientificname'):
        if s.find_parent(class_='entry') is div:
            t=clean_text(s)
            if t and t not in sci: sci.append(t)
    related=[]
    # subentry and complex form references
    for h in div.find_all(class_='headword'):
        t=clean_text(h)
        if t and t != headword and t not in related: related.append(t)
    reverse=[]
    for r in div.find_all(class_='reverseabbr'):
        t=clean_text(r)
        if t and t not in reverse: reverse.append(t)
    entries.append({
        'xml_id': eid,
        'headword': headword,
        'part_of_speech': '; '.join(poss),
        'morph_type': '; '.join(morph_types),
        'english_gloss': '; '.join(defs),
        'dialect_labels': '; '.join(dialects),
        'scientific_name': '; '.join(sci),
        'related_forms': '; '.join(related),
        'relationship_notes': '; '.join(reverse),
        'source': 'Louise Baird XML dictionary 2022-10-04',
        'raw_entry_text': clean_text(div)[:3000],
    })

xml_csv = BASE/'02_extracted/louise_xml_2022/louise_xml_entries.csv'
fields=list(entries[0].keys())
with xml_csv.open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=fields)
    w.writeheader(); w.writerows(entries)
(BASE/'02_extracted/louise_xml_2022/louise_xml_entries.json').write_text(json.dumps(entries, ensure_ascii=False, indent=2), encoding='utf-8')

# Load Claude master table pipe-delimited
sketch_path = BASE/'02_extracted/sketch_grammar_claude/01_MASTER_LEXICAL_TABLE.csv'
sketch=[]
with sketch_path.open(encoding='utf-8-sig', newline='') as f:
    r=csv.DictReader(f, delimiter='|')
    for row in r:
        if row.get('headword'):
            row['source']='Sketch Grammar Claude extraction'
            sketch.append(row)

def norm(s):
    s = (s or '').lower().strip()
    s = s.replace('·','').replace('ˈ','').replace('/','')
    s = re.sub(r'[^a-zŋɲɟḏ̪]+','',s)
    # common text conversions from orthography symbols if present
    s = s.replace('ŋ','ng').replace('ɲ','ny').replace('ɟ','dj')
    return s

xml_by_norm={}
for e in entries:
    xml_by_norm.setdefault(norm(e['headword']), []).append(e)
xml_norms=list(xml_by_norm.keys())

comparison=[]
missing=[]
exact=[]
variants=[]
for row in sketch:
    h=row.get('headword','').strip()
    n=norm(h)
    status=''
    matched=''
    confidence=''
    note=''
    if n in xml_by_norm:
        status='exact_or_normalised_match'
        matched='; '.join(sorted({e['headword'] for e in xml_by_norm[n]}))
        confidence='HIGH'
        exact.append(row)
    else:
        # fuzzy matches
        matches=difflib.get_close_matches(n, xml_norms, n=5, cutoff=0.88)
        if matches:
            status='probable_variant_or_spelling_drift'
            matched='; '.join(sorted({e['headword'] for m in matches for e in xml_by_norm[m]}))
            confidence='MEDIUM'
            variants.append(row)
        else:
            status='not_found_in_xml_candidate'
            confidence='REVIEW'
            missing.append(row)
    if row.get('suffixes') and row.get('suffixes') not in ('none',''):
        note='contains recorded suffix or morphology note; check whether lexical headword or derived form'
    comparison.append({
        'sketch_headword': h,
        'sketch_gloss': row.get('english_gloss',''),
        'sketch_pos': row.get('part_of_speech',''),
        'sketch_page': row.get('source_page',''),
        'sketch_confidence': row.get('confidence_score',''),
        'xml_match_status': status,
        'matched_xml_headword': matched,
        'match_confidence': confidence,
        'review_note': note,
        'raw_source_text': row.get('raw_source_text',''),
        'morphology_notes': row.get('morphology_notes',''),
        'suffixes': row.get('suffixes',''),
    })

cmp_fields=list(comparison[0].keys())
for name, rows in [
    ('xml_vs_sketch_comparison.csv', comparison),
    ('sketch_missing_from_xml_candidates.csv', [c for c in comparison if c['xml_match_status']=='not_found_in_xml_candidate']),
    ('sketch_probable_variants.csv', [c for c in comparison if c['xml_match_status']=='probable_variant_or_spelling_drift']),
    ('sketch_exact_matches.csv', [c for c in comparison if c['xml_match_status']=='exact_or_normalised_match']),
]:
    with (BASE/'03_consolidation'/name).open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=cmp_fields)
        w.writeheader(); w.writerows(rows)

# Priority review file
priority=[]
for c in comparison:
    if c['xml_match_status']!='exact_or_normalised_match' or c['review_note']:
        priority.append(c)
with (BASE/'04_review/priority_manual_review.csv').open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=cmp_fields)
    w.writeheader(); w.writerows(priority)

# Summary README
summary=f"""Ngunnawal Language Database Working Package\n\nStep completed: source files placed into the right structure and first comparison run completed.\n\nCounts\n- Louise XML entries parsed: {len(entries)}\n- Unique XML headwords: {len(set(e['headword'] for e in entries))}\n- Sketch Grammar rows from Claude master table: {len(sketch)}\n- Exact or normalised sketch matches in XML: {sum(1 for c in comparison if c['xml_match_status']=='exact_or_normalised_match')}\n- Probable spelling or variant matches: {sum(1 for c in comparison if c['xml_match_status']=='probable_variant_or_spelling_drift')}\n- Sketch candidates not found in XML: {sum(1 for c in comparison if c['xml_match_status']=='not_found_in_xml_candidate')}\n- Priority manual review rows: {len(priority)}\n\nFolder structure\n00_READ_ME_FIRST\n01_sources/original\n02_extracted/louise_xml_2022\n02_extracted/sketch_grammar_claude\n03_consolidation\n04_review\n05_scripts\n\nImportant caution\nThis is a mechanical comparison only. It does not decide whether a word is correct, standard, regional, borrowed, shared, or usable. It only shows where the current source files overlap or diverge.\n\nNext step\nOpen 04_review/priority_manual_review.csv and check the not_found_in_xml_candidate rows first.\n"""
(BASE/'00_READ_ME_FIRST/README_FIRST.md').write_text(summary, encoding='utf-8')

# Scripts copy current script
shutil.copy2('/mnt/data/build_ngunnawal_package.py', BASE/'05_scripts/build_ngunnawal_package.py')

# Zip package
zip_path=Path('/mnt/data/ngunnawal_language_database_package.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in BASE.rglob('*'):
        z.write(p, p.relative_to(BASE.parent))
print(summary)
print('ZIP', zip_path)
